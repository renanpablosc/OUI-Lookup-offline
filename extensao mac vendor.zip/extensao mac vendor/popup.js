document.addEventListener("DOMContentLoaded", function () {
  const button = document.getElementById("lookupBtn");
  const input = document.getElementById("macInput");
  const result = document.getElementById("result");

  button.addEventListener("click", async () => {
    const mac = input.value.trim().toUpperCase().replace(/[^A-F0-9]/g, "");
    const prefix = mac.substring(0, 6);

    try {
      const response = await fetch(chrome.runtime.getURL("oui.json"));
      const data = await response.json();
      result.textContent = "Fabricante: " + (data[prefix] || "Desconhecido");
    } catch (err) {
      console.error(err);
      result.textContent = "Erro ao buscar dados.";
    }
  });
});